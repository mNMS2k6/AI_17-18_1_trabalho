##################################################################################
#Sistema Operativo
#Distributor ID:	LinuxMint
#Description:	Linux Mint 18.2 Sonya
#Release:	18.2
#Codename:	sonya

##################################################################################
#->Versao do compilador:
#openjdk version "1.8.0_151"
#OpenJDK Runtime Environment (build 1.8.0_151-8u151-b12-0ubuntu0.16.04.2-b12)
#OpenJDK 64-Bit Server VM (build 25.151-b12, mixed mode)


##################################################################################
#->Compilacao e Execucao do programa:
# javac Jogo15.java && java Jogo15

##################################################################################
#bibliotecas do Java utilizadas:
<java.util.*>
<java.io.*>

##########################################################
#Significado das letras no caminho
# b -> Peça 0 move para baixo
# c -> Peça 0 move para cima 
# e -> Peça 0 move para esquerda
# d -> Peça 0 move para direita
##################################################################################